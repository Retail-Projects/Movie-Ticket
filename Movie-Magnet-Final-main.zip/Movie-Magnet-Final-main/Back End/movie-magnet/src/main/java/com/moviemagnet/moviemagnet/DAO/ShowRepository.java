package com.moviemagnet.moviemagnet.DAO;

import com.moviemagnet.moviemagnet.Entity.Show;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShowRepository extends JpaRepository<Show,Long> {

}
