package com.moviemagnet.moviemagnet.DAO;//package com.movie.DAO;
//
import com.moviemagnet.moviemagnet.Entity.Theatre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TheatreRepository extends JpaRepository<Theatre,Long> {

}
