package com.moviemagnet.moviemagnet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieMagnetApplicationTests {

	@Test
	void contextLoads() {
	}

}
