import Locations from "./Locations";
import NavBar2 from "./NavBar2";

export default function HomePage()
{
  return(
    <>
    <NavBar2/>
    <Locations/>
    </>
  )
}