export default function MyTickets(){
    return(
        <div>
            <h1>There is no ordered tickets</h1>
        </div>
    )
}