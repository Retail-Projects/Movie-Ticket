export default function Seatings(){
    return(
        <h1>hi</h1>
    )
}